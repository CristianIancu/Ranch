#pragma once

#include "../Game.h"
#include "ECS.h"
#include "Components.h"

class KeyboardController : public Component
{
public:
	TransformComponent *transform;
	SpriteComponent *sprite;

	void init() override
	{
		transform = &entity->getComponent<TransformComponent>();
		sprite = &entity->getComponent<SpriteComponent>();
	}

	//________________________________________________________________
/*


	while( !quit )
	{
		//Handle events on queue
		while( SDL_PollEvent( &e ) != 0 )
		{
			//User requests quit
			if( e.type == SDL_QUIT )
			{
				quit = true;
			}
				//Window event
			else if( e.type == SDL_WINDOWEVENT )
			{
				//Window resize/orientation change
				if( e.window.event == SDL_WINDOWEVENT_SIZE_CHANGED )
				{
					//Get screen dimensions
					gScreenRect.w = e.window.data1;
					gScreenRect.h = e.window.data2;

					//Update screen
					SDL_RenderPresent( gRenderer );
				}
			}
				//Touch down
			else if( e.type == SDL_FINGERDOWN )
			{
				touchLocation.x = e.tfinger.x * gScreenRect.w;
				touchLocation.y = e.tfinger.y * gScreenRect.h;
				currentTexture = &gTouchDownTexture;
			}
				//Touch motion
			else if( e.type == SDL_FINGERMOTION )
			{
				touchLocation.x = e.tfinger.x * gScreenRect.w;
				touchLocation.y = e.tfinger.y * gScreenRect.h;
				currentTexture = &gTouchMotionTexture;
			}
				//Touch release
			else if( e.type == SDL_FINGERUP )
			{
				touchLocation.x = e.tfinger.x * gScreenRect.w;
				touchLocation.y = e.tfinger.y * gScreenRect.h;
				currentTexture = &gTouchUpTexture;
			}
		}

		//Clear screen
		SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );
		SDL_RenderClear( gRenderer );

		//Render touch texture
		currentTexture->render( touchLocation.x - currentTexture->getWidth() / 2, touchLocation.y - currentTexture->getHeight() / 2 );

		//Update screen
		SDL_RenderPresent( gRenderer );
	}







	*/
	//________________________________________________________________

	void update() override
	{
		if (Game::event.type == SDL_KEYDOWN)
		{
			switch (Game::event.key.keysym.sym)
			{
			case SDLK_w:
				transform->velocity.y = -1;
				sprite->Play("Walk");
				break;
			case SDLK_a:
				transform->velocity.x = -1;
				sprite->Play("Walk");
				sprite->spriteFlip = SDL_FLIP_HORIZONTAL;
				break;
			case SDLK_d:
				transform->velocity.x = 1;
				sprite->Play("Walk");
				break;
			case SDLK_s:
				transform->velocity.y = 1;
				sprite->Play("Walk");
				break;
			default:
				break;
			}
		}
	
		if (Game::event.type == SDL_KEYUP)
		{
			switch (Game::event.key.keysym.sym)
			{
			case SDLK_w:
				transform->velocity.y = 0;
				sprite->Play("Idle");
				break;
			case SDLK_a:
				transform->velocity.x = 0;
				sprite->Play("Idle");
				sprite->spriteFlip = SDL_FLIP_NONE;
				break;
			case SDLK_d:
				transform->velocity.x = 0;
				sprite->Play("Idle");
				break;
			case SDLK_s:
				transform->velocity.y = 0;
				sprite->Play("Idle");
				break;
			case SDLK_ESCAPE:
				Game::isRunning = false;
			default:
				break;
			}
		}
	}
};